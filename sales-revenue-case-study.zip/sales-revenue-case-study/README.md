# Sales & Revenue Case Study

This case study contains SQL queries, a sample dataset and a Python script for exploratory analysis.