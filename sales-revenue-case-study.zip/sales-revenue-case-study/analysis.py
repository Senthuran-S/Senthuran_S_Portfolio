import pandas as pd

df = pd.read_csv('sales_sample.csv')
print(df.head())